from django.urls import path
from . import views

app_name="blog"

urlpatterns = [
	path('', views.BlogHome.as_view(), name='blog_home'),
	path('create/', views.BlogCreate.as_view(), name='blog_create'),
	path('<str:slug>/', views.BlogDetail.as_view(), name='blog_detail'),
	path('<str:slug>/update/', views.BlogUpdate.as_view(), name='blog_update'),
	path('<str:slug>/delete/', views.BlogDelete.as_view(), name='blog_delete'),
]