from django import forms
from django.forms import ModelForm, Textarea
from .models import Blog



class BlogCreateForm(forms.ModelForm):
	content 	= forms.CharField(widget=forms.Textarea)
	

	class Meta:
		model = Blog
		fields = '__all__'
		widgets = {
          'content': Textarea(attrs={'rows':80, 'cols':100}),
        }
