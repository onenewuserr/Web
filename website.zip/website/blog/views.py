from django.shortcuts import render, redirect
from django.urls import reverse

from .forms import BlogCreateForm
from .models import Blog
from django.views.generic import (
	ListView,
	DetailView,
	CreateView,
	UpdateView,
	DeleteView
	)


class BlogHome(ListView):
	model = Blog
	template_name = "blog/blog_home.html"

class BlogDetail(DetailView):
	model = Blog
	template_name = "blog/blog_detail.html"

	def get_success_url(self):
		return reverse('blog:blog_home')

class BlogCreate(CreateView):
	model = Blog
	form_class = BlogCreateForm
	template_name = "blog/blog_create.html"

	def get_success_url(self):
		return reverse('blog:blog_home')

class BlogUpdate(UpdateView):
	model = Blog
	form_class = BlogCreateForm
	template_name = "blog/blog_update.html"

	def get_success_url(self):
		return reverse('blog:blog_home')


class BlogDelete(DeleteView):
	model = Blog
	template_name = "blog/blog_delete.html"

	def get_success_url(self):
		return reverse('blog:blog_home')
