from django.db import models



class Blog(models.Model):
	title 		= models.CharField(max_length=100)
	slug		= models.SlugField(max_length=120, unique=True)
	content 	= models.TextField(max_length=10000)
	image		= models.ImageField(upload_to="static/images/images", blank=True)
	timestamp	= models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.slug
