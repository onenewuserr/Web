from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.conf import settings
from .models import Contact

User = settings.AUTH_USER_MODEL

class CreateUser(UserCreationForm):
	model = User
	fields = [
		'__all__'
	]


class ContactForm(forms.ModelForm):
	class Meta:
		model = Contact
		fields = '__all__'