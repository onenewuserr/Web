from django.db import models
from django.conf import settings


User = settings.AUTH_USER_MODEL



class Contact(models.Model):
	email		= models.EmailField(max_length=100)
	message		= models.TextField(max_length=1000)

	def __str__(self):
		return self.email

class Profile(models.Model):
	user 		= models.ForeignKey(User, on_delete=models.CASCADE)
	profile_pic	= models.ImageField(upload_to='static/images/profile_pics')
	bio			= models.TextField(max_length=1200)

	def __str__(self):
		return self.user.username

