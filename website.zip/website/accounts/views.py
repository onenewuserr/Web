from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from .forms import CreateUser, ContactForm


def register(request):
	form = CreateUser(request.POST)
	if request.method == 'POST':
		form = CreateUser(request.POST or None)
		if form.is_valid():
			form.save()
			messages.success(request, "Thank you for registering with website!")
			return redirect('/accounts/login')
	context = {'form': form}
	return render(request, 'accounts/register.html', context)


def user_login(request):
	if request.method == 'POST':
		username = request.POST.get('login-user')
		password = request.POST.get('login-password')
		user = authenticate(request, username=username, password=password)
		if user is not None:
			login(request, user)
			messages.success(request, "Welcome, {}".format(user))
			return redirect('/')
		else:
			messages.error(request, "Incorrect username or password.")
	return render(request, 'accounts/login.html', {})


def user_logout(request):
	logout(request)
	messages.success(request, "Logged out successfully.")
	return redirect('/accounts/login')


def contact(request):
	form = ContactForm(request.POST or None)
	if request.method == "POST":
		form = ContactForm(request.POST or None)
		if form.is_valid():
			form.save()
			messages.success(request, "Thank you")
			return redirect('/')
	context = {'form': form}
	return render(request, 'accounts/contact.html', context)



def profile(request):
	return render(request, 'accounts/profile.html', {})