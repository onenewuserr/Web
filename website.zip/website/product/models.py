from django.db import models




class Product(models.Model):
	title		= models.CharField(max_length=120)
	slug		= models.SlugField(max_length=120, unique=True)
	price		= models.FloatField()
	featured	= models.BooleanField(default=False)
	image		= models.ImageField(upload_to='static/images/images/product-img')
	timestamp	= models.DateTimeField(auto_now_add=True)

