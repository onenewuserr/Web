from django.shortcuts import render
from django.urls import reverse
from .models import Product
from .forms import ProductForm

from django.views.generic import ( 
	ListView,
	CreateView)


class ProductList(ListView):
	model = Product
	template_name = 'product_list.html'

class ProductCreate(CreateView):
	model = Product
	form_class = ProductForm
	template_name = 'product/product_create.html'

	def get_success_url(self):
		return reverse('product:product-list')